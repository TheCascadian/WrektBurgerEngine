# Earth1930 Politics Icon Sprite Sheets

Six sequential 1920×1920 PNG sprite sheets. 183 inventory entries selected by the source inventory rule (status begins with `MISSING_`), in inventory order. Sheets 001–005 cover identifiers 1–180; sheet 006 covers 181–183, with remaining cells requested as blank background.

Each sheet has separate JSON and CSV manifests. Row/column mapping is exact inventory order (left-to-right, top-to-bottom); expected asset paths preserved. Generated visual sheets should be reviewed before production slicing: image generation can vary icon placement/details despite explicit grid instructions.
